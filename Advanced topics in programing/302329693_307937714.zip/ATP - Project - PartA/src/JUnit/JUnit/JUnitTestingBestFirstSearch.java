/*package JUnit;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class JUnitTestingBestFirstSearch {

    @Test
    void solve() {
        //assertEquals();

    }

    @Test
    void name() {
    }

}*/