public enum Type {
    DISCOVER,
    OFFER,
    REQUEST,
    ACK,
    NACK,
}
