
Authors: Omer Nagar 307937714 & Asi Zaks 302329693

****Create new dictionary****

1) Press set path.

2) Browse for both paths / paste them in the right place.
			(make sure that after each paste you click 'Enter')

3)Press Accept.

4)Choose if to stem.

5)Press Connect To Engine and wait for output.


****Create new dictionary****

1) Press set path.

2) Browse / Path to the dictionary holding the Posting folder.

3)Press Accept.

4)Choose if to use stemmed dictionary or not.

5)Press Load dictionary.

6)Press Display dictionary.